#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

const int mod = 1000000007;

// Returns n ^ (-1) % p
unsigned long long inverse(unsigned long long n, int p) {
    unsigned long long ans = 1;

    unsigned long long x = n;
    int y = p - 2;

    x = x % p;

    // Calculates (x ^ y) % p
    while (y) {
        // If y is odd, multiply x with result
        if (y % 2 == 1)
            ans = (ans * x) % p;

        // y will now be even
        y /= 2;
        x = (x * x) % p;
    }
    return ans;
}

// Calculates nCr % p using Fermat's little theorem
unsigned long long nCrModPFermat(unsigned long long n,
                                 int r) {
    // If n<r, then nCr should return 0
    if (n < r)
        return 0;
    // Base case
    if (r == 0)
        return 1;

    // Find all factorial of r, n
    // and n-r
    vector<unsigned long long> factorial;
    factorial.assign(n + 1, 0);
    factorial[0] = 1;
    unsigned long long i = 1;

    while (i <= n) {
        factorial[i] = (factorial[i - 1] * i) % mod;
        ++i;
    }

    unsigned long long ans = (factorial[n] * inverse(factorial[r], mod) % mod
            * inverse(factorial[n - r], mod) % mod) % mod;

    return ans;
}

int type1(int x, int y) {
    return nCrModPFermat(x + 1, y);
}

int type2(int x, int y) {
	unsigned long long sum = 0;
    unsigned int i = ceil(y / 2);
    while (i <= y) {
        sum = (sum + nCrModPFermat(x + 1, i) *
		nCrModPFermat(i, y - i) % mod) % mod;
        i++;
    }

	return sum;
}

int main() {
    freopen("semnale.in", "r", stdin);
	freopen("semnale.out", "w", stdout);

	int sig_type, x, y;

	cin >> sig_type >> x >> y;

    switch (sig_type) {
		case 1:
			cout << type1(x, y);;
			break;
		case 2:
			cout << type2(x, y);
			break;
		default:
			cout << "wrong task number" << endl;
	}

    return 0;
}
